FICTIONAL RESTAURANT TEST DATA — November 7–13, 2026
menu.csv: dish,price,category,photo
sales.csv: date,dish,quantity (70 rows)
Photos are NOT included. Add 10 appropriately licensed JPG images to photos/ with filenames from menu.csv.
All quantities are synthetic and not actual restaurant sales.
